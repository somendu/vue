/**
 * 
 */
package com.data.story.spring.views.common;

import com.vaadin.flow.dom.DomEvent;
import com.vaadin.flow.dom.DomEventListener;

/**
 * @author somendu
 *
 */
public class ScrollEventListener implements DomEventListener {

	@Override
	public void handleEvent(DomEvent event) {

	}

}
